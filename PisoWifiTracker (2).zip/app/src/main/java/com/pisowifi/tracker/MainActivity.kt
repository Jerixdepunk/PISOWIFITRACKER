package com.pisowifi.tracker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Date

class MainActivity : AppCompatActivity() {

    private lateinit var tvSsid: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvElapsed: TextView
    private lateinit var tvConsumed: TextView
    private lateinit var tvRemaining: TextView
    private lateinit var etPurchaseMinutes: EditText
    private lateinit var btnAddPurchase: Button
    private lateinit var btnReset: Button
    private lateinit var listHistory: ListView

    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startMonitoringService() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSsid = findViewById(R.id.tvSsid)
        tvStatus = findViewById(R.id.tvStatus)
        tvElapsed = findViewById(R.id.tvElapsed)
        tvConsumed = findViewById(R.id.tvConsumed)
        tvRemaining = findViewById(R.id.tvRemaining)
        etPurchaseMinutes = findViewById(R.id.etPurchaseMinutes)
        btnAddPurchase = findViewById(R.id.btnAddPurchase)
        btnReset = findViewById(R.id.btnReset)
        listHistory = findViewById(R.id.listHistory)

        btnAddPurchase.setOnClickListener {
            val ssid = PrefsHelper.getActiveSsid(this)
            val minutesStr = etPurchaseMinutes.text.toString()
            if (ssid == null) {
                Toast.makeText(this, "Connect to a Piso Wifi network first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val minutes = minutesStr.toLongOrNull()
            if (minutes == null || minutes <= 0) {
                Toast.makeText(this, "Enter a valid number of minutes", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            PrefsHelper.addPurchase(this, ssid, minutes)
            etPurchaseMinutes.text.clear()
            refreshUI()
        }

        btnReset.setOnClickListener {
            val ssid = PrefsHelper.getActiveSsid(this)
            if (ssid == null) {
                Toast.makeText(this, "No active network to reset", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            PrefsHelper.resetNetwork(this, ssid)
            refreshUI()
        }

        requestPermissionsAndStart()
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isEmpty()) {
            startMonitoringService()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun startMonitoringService() {
        val intent = Intent(this, WifiMonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    override fun onResume() {
        super.onResume()
        polling = true
        handler.post(pollRunnable)
    }

    override fun onPause() {
        super.onPause()
        polling = false
        handler.removeCallbacks(pollRunnable)
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            refreshUI()
            if (polling) handler.postDelayed(this, 1000)
        }
    }

    private fun refreshUI() {
        val ssid = PrefsHelper.getActiveSsid(this)
        if (ssid == null) {
            tvSsid.text = "Not connected to a tracked Wi-Fi"
            tvStatus.text = "Status: Disconnected"
            tvElapsed.text = "Elapsed this session: 00:00:00"
            tvConsumed.text = "Total consumed: --"
            tvRemaining.text = "Remaining: --"
        } else {
            val record = PrefsHelper.getRecord(this, ssid)
            val elapsed = if (record.sessionStartMillis > 0)
                (System.currentTimeMillis() - record.sessionStartMillis) / 1000 else 0
            val totalConsumed = record.consumedSeconds + elapsed
            val remaining = record.purchasedSeconds - totalConsumed

            tvSsid.text = "Network: $ssid"
            tvStatus.text = "Status: Connected"
            tvElapsed.text = "Elapsed this session: ${formatDuration(elapsed)}"
            tvConsumed.text = "Total consumed: ${formatDuration(totalConsumed)}"
            tvRemaining.text = "Remaining (per your purchase log): ${formatDuration(remaining)}"
        }

        val history = PrefsHelper.getHistory(this)
        val items = history.map {
            val connect = DateFormat.format("MM/dd hh:mm:ss a", Date(it.connectMillis))
            val disconnect = DateFormat.format("hh:mm:ss a", Date(it.disconnectMillis))
            val durationSec = (it.disconnectMillis - it.connectMillis) / 1000
            "${it.ssid}\n$connect → $disconnect  (${formatDuration(durationSec)})"
        }
        listHistory.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
    }

    private fun formatDuration(totalSeconds: Long): String {
        val sign = if (totalSeconds < 0) "-" else ""
        val abs = Math.abs(totalSeconds)
        val h = abs / 3600
        val m = (abs % 3600) / 60
        val s = abs % 60
        return String.format("%s%02d:%02d:%02d", sign, h, m, s)
    }
}
