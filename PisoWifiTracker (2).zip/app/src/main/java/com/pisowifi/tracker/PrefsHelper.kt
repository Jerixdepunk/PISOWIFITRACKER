package com.pisowifi.tracker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class NetworkRecord(
    val ssid: String,
    var purchasedSeconds: Long = 0L,
    var consumedSeconds: Long = 0L,
    var sessionStartMillis: Long = 0L // 0 means not currently connected
)

data class SessionLog(
    val ssid: String,
    val connectMillis: Long,
    val disconnectMillis: Long
)

/**
 * All data is stored locally on-device in SharedPreferences. Nothing is
 * transmitted anywhere. This is purely a personal log of how long your
 * device has actually been associated with each Wi-Fi network, so you can
 * compare it against what a piso/peso Wi-Fi vending machine claims.
 */
object PrefsHelper {
    private const val PREFS_NAME = "piso_wifi_tracker_prefs"
    private const val KEY_RECORDS = "records"
    private const val KEY_HISTORY = "history"
    private const val KEY_ACTIVE_SSID = "active_ssid"
    private const val MAX_HISTORY = 200

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getRecord(context: Context, ssid: String): NetworkRecord {
        return getAllRecords(context)[ssid] ?: NetworkRecord(ssid)
    }

    fun getAllRecords(context: Context): MutableMap<String, NetworkRecord> {
        val json = prefs(context).getString(KEY_RECORDS, "{}") ?: "{}"
        val obj = JSONObject(json)
        val map = mutableMapOf<String, NetworkRecord>()
        obj.keys().forEach { ssid ->
            val r = obj.getJSONObject(ssid)
            map[ssid] = NetworkRecord(
                ssid = ssid,
                purchasedSeconds = r.optLong("purchasedSeconds", 0L),
                consumedSeconds = r.optLong("consumedSeconds", 0L),
                sessionStartMillis = r.optLong("sessionStartMillis", 0L)
            )
        }
        return map
    }

    private fun writeAll(context: Context, all: Map<String, NetworkRecord>) {
        val obj = JSONObject()
        all.forEach { (ssid, r) ->
            val ro = JSONObject()
            ro.put("purchasedSeconds", r.purchasedSeconds)
            ro.put("consumedSeconds", r.consumedSeconds)
            ro.put("sessionStartMillis", r.sessionStartMillis)
            obj.put(ssid, ro)
        }
        prefs(context).edit().putString(KEY_RECORDS, obj.toString()).apply()
    }

    fun saveRecord(context: Context, record: NetworkRecord) {
        val all = getAllRecords(context)
        all[record.ssid] = record
        writeAll(context, all)
    }

    fun startSession(context: Context, ssid: String) {
        val record = getRecord(context, ssid)
        if (record.sessionStartMillis == 0L) {
            record.sessionStartMillis = System.currentTimeMillis()
            saveRecord(context, record)
        }
        prefs(context).edit().putString(KEY_ACTIVE_SSID, ssid).apply()
    }

    fun endSession(context: Context, ssid: String) {
        val record = getRecord(context, ssid)
        if (record.sessionStartMillis != 0L) {
            val now = System.currentTimeMillis()
            val durationSec = (now - record.sessionStartMillis) / 1000
            record.consumedSeconds += durationSec
            addHistory(context, SessionLog(ssid, record.sessionStartMillis, now))
            record.sessionStartMillis = 0L
            saveRecord(context, record)
        }
        prefs(context).edit().remove(KEY_ACTIVE_SSID).apply()
    }

    fun getActiveSsid(context: Context): String? = prefs(context).getString(KEY_ACTIVE_SSID, null)

    fun addPurchase(context: Context, ssid: String, minutes: Long) {
        val record = getRecord(context, ssid)
        record.purchasedSeconds += minutes * 60
        saveRecord(context, record)
    }

    fun resetNetwork(context: Context, ssid: String) {
        val all = getAllRecords(context)
        all.remove(ssid)
        writeAll(context, all)
    }

    private fun addHistory(context: Context, log: SessionLog) {
        val arr = getHistoryArray(context)
        val entry = JSONObject()
        entry.put("ssid", log.ssid)
        entry.put("connectMillis", log.connectMillis)
        entry.put("disconnectMillis", log.disconnectMillis)
        arr.put(entry)

        val trimmed = JSONArray()
        val start = maxOf(0, arr.length() - MAX_HISTORY)
        for (i in start until arr.length()) {
            trimmed.put(arr.get(i))
        }
        prefs(context).edit().putString(KEY_HISTORY, trimmed.toString()).apply()
    }

    fun getHistory(context: Context): List<SessionLog> {
        val arr = getHistoryArray(context)
        val list = mutableListOf<SessionLog>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                SessionLog(
                    o.getString("ssid"),
                    o.getLong("connectMillis"),
                    o.getLong("disconnectMillis")
                )
            )
        }
        return list.reversed()
    }

    private fun getHistoryArray(context: Context): JSONArray {
        val json = prefs(context).getString(KEY_HISTORY, "[]") ?: "[]"
        return JSONArray(json)
    }
}
