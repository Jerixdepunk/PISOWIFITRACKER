package com.pisowifi.tracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class WifiMonitorService : Service() {

    private lateinit var connectivityManager: ConnectivityManager
    private var currentSsid: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private var tickerRunning = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            val caps = connectivityManager.getNetworkCapabilities(network)
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                val ssid = getCurrentSsid()
                if (ssid != null && ssid != "<unknown ssid>") {
                    currentSsid = ssid
                    PrefsHelper.startSession(applicationContext, ssid)
                    startTicker()
                }
            }
        }

        override fun onLost(network: Network) {
            val ssid = currentSsid
            if (ssid != null) {
                PrefsHelper.endSession(applicationContext, ssid)
                currentSsid = null
            }
            stopTicker()
            updateNotification("Disconnected", "Waiting for Wi-Fi connection…")
        }
    }

    override fun onCreate() {
        super.onCreate()
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Piso Wifi Tracker", "Monitoring Wi-Fi connections…"))

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        connectivityManager.registerNetworkCallback(request, networkCallback)

        // In case the service starts while already connected to Wi-Fi
        val ssid = getCurrentSsid()
        if (ssid != null && ssid != "<unknown ssid>") {
            currentSsid = ssid
            PrefsHelper.startSession(applicationContext, ssid)
            startTicker()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (e: Exception) {
            // callback may already be unregistered
        }
        stopTicker()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun getCurrentSsid(): String? {
        return try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val info = wifiManager.connectionInfo
            var ssid = info.ssid ?: return null
            if (ssid.startsWith("\"") && ssid.endsWith("\"")) {
                ssid = ssid.substring(1, ssid.length - 1)
            }
            ssid
        } catch (e: Exception) {
            null
        }
    }

    private fun startTicker() {
        if (tickerRunning) return
        tickerRunning = true
        handler.post(tickerRunnable)
    }

    private fun stopTicker() {
        tickerRunning = false
        handler.removeCallbacks(tickerRunnable)
    }

    private val tickerRunnable = object : Runnable {
        override fun run() {
            val ssid = currentSsid
            if (ssid != null) {
                val record = PrefsHelper.getRecord(applicationContext, ssid)
                val elapsed = if (record.sessionStartMillis > 0)
                    (System.currentTimeMillis() - record.sessionStartMillis) / 1000 else 0
                val totalConsumed = record.consumedSeconds + elapsed
                val remaining = record.purchasedSeconds - totalConsumed
                updateNotification(
                    "Connected: $ssid",
                    "Consumed: ${formatDuration(totalConsumed)}  •  Remaining: ${formatDuration(remaining)}"
                )
            }
            if (tickerRunning) handler.postDelayed(this, 1000)
        }
    }

    private fun formatDuration(totalSeconds: Long): String {
        val sign = if (totalSeconds < 0) "-" else ""
        val abs = Math.abs(totalSeconds)
        val h = abs / 3600
        val m = (abs % 3600) / 60
        val s = abs % 60
        return String.format("%s%02d:%02d:%02d", sign, h, m, s)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Piso Wifi Monitoring",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        val notification = buildNotification(title, text)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, notification)
    }

    companion object {
        const val CHANNEL_ID = "piso_wifi_channel"
        const val NOTIF_ID = 1001
    }
}
