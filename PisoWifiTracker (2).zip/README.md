# Piso Wifi Tracker

A personal Android app that logs how long *your device* has actually been
connected to any Wi-Fi network (built for checking piso/peso Wi-Fi vending
machines). It timestamps each connection, pauses the timer automatically
when Wi-Fi drops, resumes it when reconnected, and keeps a session history
so you can compare real connected time against what the machine claims.

Everything is stored locally on the phone (SharedPreferences). Nothing is
sent anywhere.

## How it works

- A foreground service listens for Wi-Fi connect/disconnect events
  (`ConnectivityManager.NetworkCallback`).
- On connect, it records the SSID and a start timestamp.
- On disconnect, it adds the elapsed time to that network's running total
  and logs the session (connect time → disconnect time) to history.
- The main screen lets you log how many minutes you purchased for the
  current network, and shows: elapsed time this session, total consumed
  time, and remaining time based on your log — so you can compare it
  against the vending machine's own countdown.

## Requirements to read the Wi-Fi name (SSID)

Android requires **Location permission** and **device Location (GPS)
turned on** for any app to read the connected Wi-Fi's SSID. The app will
ask for this permission on first launch. If Location is off, the SSID
will show as unknown and sessions won't be tracked per-network correctly.

## Building the APK yourself (GitHub Actions)

1. Create a new GitHub repository and push the contents of this folder to
   it (including the `.github/workflows/build-apk.yml` file).
2. Go to the repo's **Actions** tab — a workflow run will start
   automatically on push (or trigger it manually via "Run workflow").
3. When it finishes, open the run and download the
   **piso-wifi-tracker-debug-apk** artifact — that's your installable
   `app-debug.apk`.
4. Transfer the APK to your phone and install it (you'll need to allow
   "install unknown apps" for whichever app you use to open it, since
   this is an unsigned debug build for personal use).

## Building locally (optional)

If you have Android Studio installed, you can just open this folder as a
project and run it directly, or run:

```
./gradlew assembleDebug
```

(Note: this repo intentionally does not ship the Gradle wrapper jar, since
the CI workflow installs Gradle itself. If you want to build locally with
`./gradlew`, run `gradle wrapper` once inside the project with a local
Gradle install to generate it.)

## Limitations / honesty note

This app measures how long *your device* is associated with the access
point at the OS level — it can't read the vending machine's internal
timer directly. What it gives you is an independent, tamper-proof log you
control, so if the machine's countdown and your own log disagree by more
than a few seconds consistently, that's good evidence to bring up with
whoever manages the piso Wi-Fi.
